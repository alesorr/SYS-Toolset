# Dispatcher Scripts

Questa cartella contiene tutti gli script relativi alla gestione
e manutenzione del componente **Dispatcher**.

## Contenuti tipici
- Riavvio servizi Dispatcher
- Pulizia code o task bloccati
- Verifica stato processi
- Raccolta log diagnostici

## Linee guida
- Gli script devono funzionare sia in produzione che in pre-produzione.
- Fornire parametri per modalità verbose e dry-run.