# Indexer Scripts

Raccolta di script destinati alla gestione del modulo **Indexer**.

## Funzionalità tipiche
- Reindicizzazione dati
- Ripristino configurazioni
- Controllo stato o performance

## Note operative
- Evitare indicizzazioni complete se non necessario.
- Integrare sempre controlli preliminari.